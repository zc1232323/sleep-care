# SleepCare 智能睡眠环境调控设备 — 项目完整交付包

> 周灿 | 东莞职业技术学院 24级计算机应用技术（中外合作办学）
> 开发周期：2026年6月 | 版本：V1.0

---

## 一、项目简介

本项目是「智能睡眠环境调控设备」的软件系统部分，包含**微信小程序（用户端）+ 云后台 API（Node.js）+ 医生端 Web 后台**。

核心原则：**不依赖真实硬件**。所有设备数据、环境调控指令均使用模拟数据或预留接口。硬件就绪后仅需替换数据源和控制指令下发模块即可接入。

---

## 二、文件清单（本包内包含的文件）

```
sleep-care/
├── 📄 README.md                              ← 本说明文档
├── 📄 SleepCare_API.postman_collection.json   ← Postman 接口集合（9个API）
├── 📄 SleepCare_环境.postman_environment.json ← Postman 环境变量
│
├── 📁 backend/                               ← 云后台 Node.js 后端
│   ├── app.js                                # Express 主入口
│   ├── server.js                             # 服务器启动
│   ├── package.json                          # 依赖清单
│   ├── routes/                               # API 路由
│   │   ├── auth.js                           # 注册/登录
│   │   ├── devices.js                        # 设备管理 CRUD
│   │   ├── reports.js                        # 睡眠报告 + 分期
│   │   └── settings.js                       # 用户设置
│   ├── middleware/
│   │   └── auth.js                           # JWT 认证中间件
│   └── db/
│       ├── connection.js                     # SQLite 连接
│       ├── schemas.js                        # 表结构定义
│       └── init.js                           # 数据库初始化
│
├── 📁 pages/                                 ← 微信小程序页面（根目录）
│   ├── login/                                # 登录页
│   ├── home/                                 # 首页（睡眠卡片）
│   ├── devices/                              # 设备列表
│   └── report/                               # 睡眠报告
│
├── 📁 components/                            ← 小程序公共组件
├── 📁 miniprogram/                           ← 小程序资源（图片等）
├── 📁 docs/                                  ← 项目文档
│   ├── 软件系统功能需求.md                    # 完整需求文档
│   ├── MVP功能清单.md                         # 功能优先级清单
│   ├── 系统架构图.md                          # 架构设计
│   ├── 数据库设计.md                          # 数据库表结构
│   ├── Postman测试指南.md                     # API 测试指南
│   ├── 第5大节截图指南.md                     # 第5节验收截图指南
│   ├── 第6大节截图指南.md                     # 第6节验收截图指南
│   ├── 第7大节截图指南.md                     # 第7节验收截图指南
│   └── 第8大节截图指南.md                     # 第8节验收截图指南
│
├── 📄 app.js                                 ← 小程序入口
├── 📄 app.json                               # 小程序配置（含 tabBar）
├── 📄 app.wxss                               # 全局样式
├── 📄 sitemap.json                           # 站点地图
└── 📄 sleep_care.db                           # SQLite 数据库文件（含测试数据）
```

---

## 三、技术栈

| 层级 | 技术 |
|------|------|
| **小程序前端** | 微信原生开发（WXML + WXSS + JS） |
| **后端 API** | Node.js + Express 4.x |
| **数据库** | SQLite（sql.js，无需安装） |
| **认证** | JWT（jsonwebtoken） |
| **密码加密** | bcryptjs |
| **接口测试** | Postman（Collection 已提供） |

---

## 四、快速上手（对方必读）

### 前置条件

- **Node.js** 18+（或任意可运行 Express 的版本）
- **微信开发者工具**（用于运行小程序）
- **Postman**（可选，用于测试 API）

### 第一步：启动后端

```bash
# 进入 backend 目录
cd backend

# 安装依赖（只需一次）
npm install

# 启动服务
npm run dev
```

看到 `[Server] SleepCare 后端服务已启动: http://localhost:3000` 即成功。

### 第二步：打开小程序

1. 打开**微信开发者工具**
2. 导入项目 → 选择 `sleep-care` 根目录
3. AppID 选「测试号」
4. 编译运行

### 第三步：导入 Postman（可选）

1. 打开 Postman → Import
2. 选中本文件夹内的两个 JSON 文件：
   - `SleepCare_API.postman_collection.json`（接口集合）
   - `SleepCare_环境.postman_environment.json`（环境变量）
3. 先跑「登录」接口 → Token 自动存入
4. 其余接口直接 Send

---

## 五、已实现的 API 接口

| # | 方法 | 路径 | 认证 | 说明 |
|---|------|------|------|------|
| 1 | GET | `/` | 否 | 健康检查 |
| 2 | POST | `/api/v1/auth/register` | 否 | 用户注册 |
| 3 | POST | `/api/v1/auth/login` | 否 | 用户登录（返回 JWT） |
| 4 | GET | `/api/v1/devices/list` | 是 | 设备列表 |
| 5 | POST | `/api/v1/devices/add` | 是 | 添加设备（虚拟/序列号） |
| 6 | PUT | `/api/v1/devices/:id` | 是 | 修改设备昵称 |
| 7 | DELETE | `/api/v1/devices/:id` | 是 | 删除设备 |
| 8 | GET | `/api/sleep/report/daily` | 是 | 每日睡眠报告 |
| 9 | GET | `/api/sleep/report/stages` | 是 | 睡眠分期数据（48点） |
| 10 | GET | `/api/sleep/noise` | 是 | 环境噪音数据（144点） |
| 11 | GET | `/api/sleep/summary` | 是 | 睡眠评分汇总（第7节） |
| 12 | GET | `/api/setting/plan` | 是 | 获取作息设置（第8节） |
| 13 | PUT | `/api/setting/plan` | 是 | 修改作息设置（第8节） |

**统一响应格式**：`{ code: 0, message: "success", data: {...} }`

---

## 六、小程序页面说明

| 页面 | 路径 | 功能 |
|------|------|------|
| 登录页 | `pages/login/` | 手机号+密码登录，记住登录状态 |
| 首页 | `pages/home/` | 睡眠评分卡片、深睡/浅睡/REM 占比、查看详细分期 |
| 设备列表 | `pages/devices/` | 查看已绑定设备、添加虚拟设备 |
| 报告页 | `pages/report/` | 分期柱状图（View实现）+ 噪音折线图 + 睡眠时长分布 |

底部导航栏（tabBar）：首页 | 设备 | 报告

---

## 七、Git 提交历史（10 个 commit）

```
947333a feat: 第8大节 - 个性化设置页面(作息设置)
c1eb3f7 fix: 首页跳报告页改用wx.storage传参
0c446a7 fix: 首页"查看详细分期"按钮跳转修复
02aafc0 feat: 第7大节 - 睡眠评分汇总API + 趋势图
622b4b4 fix: 同步miniprogram目录下report页文件到View柱状图版
2eeb52f feat: 噪音API + 报告页双图表（分期柱状图+噪音折线图）
eabf358 feat: tabBar底部导航（首页/设备/报告）+ 6个图标
3e3a6ce feat: 睡眠分期API（数据库版）
36b3cc7 feat: 睡眠报告 API + 首页睡眠卡片
86cdaea feat: 微信小程序初始化（登录页 + 设备列表页）
```

---

## 八、数据库核心表

| 表名 | 说明 |
|------|------|
| `users` | 用户表（手机号、昵称、角色等） |
| `devices` | 设备表（虚拟设备标记 is_virtual） |
| `sleep_reports` | 睡眠报告（含心率曲线、分期曲线等 JSON 字段） |
| `user_settings` | 用户个性化设置（作息时间/勿扰模式等） |

数据库文件 `sleep_care.db` 已包含测试数据，可直接使用。

---

## 九、常见问题

**Q: 启动后端报 `sql.js` 找不到？**
A: 运行 `cd backend && npm install`，安装所有依赖。

**Q: 小程序请求报网络错误？**
A: 检查后端是否启动，以及小程序代码中 `baseUrl` 的 IP 地址是否正确（默认 `localhost:3000`，模拟器可能需改为局域网 IP）。

**Q: Postman 导入后接口报 401？**
A: 先跑「登录」接口获取 Token（会自动存入环境变量），再跑其他接口。

**Q: 如何添加测试数据？**
A: 先注册 → 登录 → 添加虚拟设备 → 调用睡眠报告 API（会自动生成模拟数据）。

---

> 📌 更多详细说明请查看 `docs/` 目录下的各文档。
> 📬 如有疑问，联系周灿（13713447274）。
