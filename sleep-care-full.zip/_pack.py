import zipfile
import os

root = r"C:\Users\z\Desktop\sleep-care"
output = r"C:\Users\z\Desktop\sleep-care\sleep-care-full.zip"

exclude_patterns = [
    "node_modules", ".git", ".workbuddy", ".pdf_pages", ".pdf_pages_all",
    "__pycache__", ".venv", "venv", "sleep-care-full.zip",
]

def should_exclude(path):
    for p in exclude_patterns:
        if p in path:
            return True
    return False

with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as zf:
    count = 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if not should_exclude(os.path.join(dirpath, d))]
        
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            if should_exclude(full):
                continue
            arcname = os.path.relpath(full, root)
            zf.write(full, arcname)
            count += 1

size_kb = os.path.getsize(output) / 1024
print(f"Done: {count} files, {size_kb:.0f} KB")
